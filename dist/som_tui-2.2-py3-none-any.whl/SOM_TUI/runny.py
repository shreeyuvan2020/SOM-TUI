from SOM_TUI.tui import Voting
def run():
    app = Voting()
    app.run()